import React, { useState } from 'react'
import { FamilyBudgetLogic } from './logic'

const FamilyBudgetManagement = () => {

    const [logic , setLogic ] = useState(new )

    let [value, setValue] = useState()
    let onSubmit = (event) => {
        event.preventDefault()
        console.log(value)
    }

    return (
        <div>
            <form onSubmit={onSubmit} className='flex m-auto mt-10 p-5 justify-center items-start w-96 h-56 rounded-3xl bg-slate-100' >

                <label >
                    Value:
                    <input type='number' onChange={(e) => { value = e.target.value }} value={value} >
                    </input>
                </label>
                
            </form>

        </div>
    )
}

export default FamilyBudgetManagement