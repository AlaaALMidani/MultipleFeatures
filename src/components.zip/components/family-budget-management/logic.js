export class FamilyBudgetLogic {

    income = []
    outcome = []
    currentBudget = 0 

    addEntry(value, type) {
        if (typeof (value) == 'number') {

            if (type === 'income') {
                this.income.push(value)
                this.currentBudget += value
            } else {
                this.outcome.push(value)
                this.currentBudget -= value
            }   
        } else {
            alert('the entry isn\'t number ')
        }
    }
}  