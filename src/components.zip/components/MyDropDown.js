import React, { useState } from 'react';

function MyDropdown({handleChange}) {
  const [selectedOption, setSelectedOption] = useState('Option 1'); // Initial value

  const options = [
    'Option 1',
    'Option 2',
    'Option 3',
    'Option 4',
  ];

  

  return (
    <div>
      <label htmlFor="myDropdown">Select an option:</label>
      <select id="myDropdown" value={selectedOption} onChange={handleChange}>
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
      <p>Selected: {selectedOption}</p> </div>
  );
}

export default MyDropdown;